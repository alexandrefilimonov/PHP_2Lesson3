﻿USE world;

CREATE TABLE IF NOT EXISTS `images` 
(
  `id` int(11) NOT NULL AUTO_INCREMENT,
  
   `name` varchar(25) NOT NULL,
  
   `size` int(11) NOT NULL,
  
   `clicks` int(11) NULL,
   
`images_info` text NULL,
  
   `date_creation` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
   PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=UTF8MB4 AUTO_INCREMENT=6 ;

INSERT INTO `images` (`name`, `size`, `clicks`, `images_info`,`date_creation`) VALUES

('1', 30349, 0, 'Букет "Подарочный"', '2018-09-02 17:54:20'),

('2', 139617, 0, 'Букет "С днем рожденья!"', '2018-09-02 17:54:20'),

('3', 45920, 0, 'Букет "Сюрприз!"', '2018-09-02 17:55:16'),

('4', 646925, 0, 'Букет "Свадебный-1"', '2018-09-02 17:55:16'),

('5', 125056, 0, 'Букет "Свадебный-2"', '2018-09-02 17:55:16');
